-- GRUPO: 
-- Pedro van Rooij Costa
-- Nelson Mariano Leite Neto
-- Bruno Freitas

module Main (main,mainA,mainB,mainC,mainD) where
import Comb
import Fact
main = print (arSim 4 2)
mainA = print (arSim 6 3)
mainB = print (arRep 4 2)
mainC = print (perCirc 8)
mainD = print (combRep 10 4)
