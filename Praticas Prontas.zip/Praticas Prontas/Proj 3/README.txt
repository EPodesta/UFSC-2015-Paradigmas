Paradigmas de Programacao
Projeto 3
Alunos: 
Pedro van Rooij Costa
Nelson Mariano Leite Neto
Bruno Freitas

Projeto 3

compilacao:

	ghc --make Principal.hs -o prog

modo de uso:

	./prog Arquivo.bmp (Tem que ser .bmp)
	
	caso o programa nao funcione em seu computador favor recompila-lo e 
	roda-lo na maquina Marte (Inf - UFSC).
	O erro (se ocorrer) e devido a uma atualizacao do ghc. 

saida:

	Arquivo_Blue.txt
	Arquivo_Green.txt
	Arquivo_Red.txt

