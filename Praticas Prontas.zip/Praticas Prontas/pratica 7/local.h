/* -- GRUPO: 
-- Pedro van Rooij Costa
-- Nelson Mariano Leite Neto
-- Bruno Freitas */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

float soluc(float,float);
