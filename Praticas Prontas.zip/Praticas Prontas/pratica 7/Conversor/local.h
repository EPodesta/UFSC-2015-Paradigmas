/* -- GRUPO: 
-- Pedro van Rooij Costa
-- Nelson Mariano Leite Neto
-- Bruno Freitas */

#include <stdio.h>
#include <stdlib.h>

#define PI 3.1415

float* paraGraus(float*);
float* paraRadianos(float*);
float* pedirParam();
void mostrarResp(int*, float*, float*);
int mostreMenu();
