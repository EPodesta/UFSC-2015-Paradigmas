/* -- GRUPO: 
-- Pedro van Rooij Costa
-- Nelson Mariano Leite Neto
-- Bruno Freitas */

#include "local.h"

float soluc(float x, float y){
        float r;
        r=sqrt(x*x+y*y);
        return r;
}


