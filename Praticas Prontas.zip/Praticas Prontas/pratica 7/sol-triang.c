/* -- GRUPO: 
-- Pedro van Rooij Costa
-- Nelson Mariano Leite Neto
-- Bruno Freitas */

/* sol-triang.c */
#include "local.h" 

int main(){
	float a, b=5.0, c=8.0; 
	a = soluc(b,c);
	printf("%f\n", a); 
	exit(0);
}

