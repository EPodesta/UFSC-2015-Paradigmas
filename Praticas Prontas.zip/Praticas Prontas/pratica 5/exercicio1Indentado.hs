-- GRUPO: 
-- Pedro van Rooij Costa
-- Nelson Mariano Leite Neto
-- Bruno Freitas

f x = case x of
	0 -> 1
	1 -> 5
	2 -> 2
	_ -> 1 
